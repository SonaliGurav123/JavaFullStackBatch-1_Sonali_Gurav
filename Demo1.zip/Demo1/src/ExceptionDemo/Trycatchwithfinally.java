package ExceptionDemo;

import java.io.FileNotFoundException;
import java.io.FileReader;

public class Trycatchwithfinally {
	public static void main(String[] args) {
		
		FileReader f=null;
		
		try
		{
			f=new FileReader("c:\\abc.txt");
		}catch(FileNotFoundException e) 
		     {
			     System.out.println(e);
		     }
		
		finally {
			try {
			f.close();
			}catch(Exception e) {System.out.println(e);}
		}
		
	}

}
