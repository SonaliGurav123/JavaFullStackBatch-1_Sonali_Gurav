package ExceptionDemo;

import java.io.FileReader;

public class Insidetry {
	public static void main(String[] args) {
		
		try(FileReader f=new FileReader("c:\\abc.txt");){
			
		}catch(Exception e) {System.out.println(e);}
	}

}
