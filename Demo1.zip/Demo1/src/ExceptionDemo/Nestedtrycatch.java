package ExceptionDemo;

public class Nestedtrycatch {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		int a=10;
		int b=0;
		
		int d[]= {2,3,4};
		
		try {
			try {
				int c=a/b;
				System.out.println("Result:"+c);
			}catch(ArithmeticException e)
			     {
				    System.out.println(e);
			     }
			
			System.out.println(d[4]);
			
		}catch(ArrayIndexOutOfBoundsException g)
		     {
			    System.out.println(g);
		     }
	}

}
