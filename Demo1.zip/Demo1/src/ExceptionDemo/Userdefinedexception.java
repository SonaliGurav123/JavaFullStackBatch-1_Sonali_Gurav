package ExceptionDemo;

public class Userdefinedexception {
	
	public static void main(String[] args) throws DepositEx 
	{
		
		int amt=999;
		if(amt<1000)
			throw new DepositEx("Minimum amount to deposit is 1000");
		else
			System.out.println("Done");
	}

}
