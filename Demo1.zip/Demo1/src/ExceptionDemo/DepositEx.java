package ExceptionDemo;

public class DepositEx extends Exception {
	
	
		DepositEx(String msg)
		{
			super(msg);		
		}

}
