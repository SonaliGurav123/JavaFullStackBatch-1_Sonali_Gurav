package ExceptionDemo;

import java.io.FileNotFoundException;
import java.io.FileReader;

public class ExampleThrows {
	
	public void show() throws FileNotFoundException,InterruptedException
	{
		FileReader f=new FileReader("c:\\abc.txt");
		Thread.sleep(5000);
	}
	
	public static void main(String[] args) throws FileNotFoundException,InterruptedException
	{
		ExampleThrows t=new ExampleThrows();
		t.show();
		
	}

}
