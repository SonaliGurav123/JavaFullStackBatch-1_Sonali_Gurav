package LamdaExpre;

import java.util.Random;
import java.util.function.Consumer;
import java.util.function.Function;
import java.util.function.Predicate;
import java.util.function.Supplier;

public class PreInterface {
	public static void main(String[] args) {
		
		Consumer<Integer> c=(a)-> System.out.println(a*a);
		c.accept(2);
		
		Supplier<Integer> s=()->new Random().nextInt(100);
		System.out.println(s.get());
		
		Predicate<Integer> p=(v)->v%2==0;
		System.out.println(p.test(3));
		
		Function<String,Integer> f1=(f)->Integer.parseInt(f);
		System.out.println(f1.apply("20"));
	}

}
