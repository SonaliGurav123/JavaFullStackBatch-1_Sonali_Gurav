package LamdaExpre;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

public class IntermediateOp {
	public static void main(String[] args) {
		List<Integer> list=Arrays.asList(4,3,6,4,2,7);
		
		System.out.println("Array:");
		list.forEach(x->System.out.println(x));

		System.out.println("Sorted array in Reverse order:");
		list.stream().sorted(Collections.reverseOrder()).forEach(x->System.out.println(x));
		
		System.out.println("Max Number:");
		Optional<Integer> max=list.stream().sorted(Collections.reverseOrder()).findFirst();
		
		if(max.isPresent())
			System.out.println(max.get());
		
		System.out.println("Copy the array in b2:");
		List<Integer> b2=list.stream().sorted(Collections.reverseOrder()).collect(Collectors.toList());
		b2.forEach(x->System.out.println(x));

		
		System.out.println("Skip a element in b2:");
		list.stream().skip(1).forEach(x->System.out.println(x));
		
		System.out.println("Filter  elements in b2:");
		list.stream().filter(x->x%2==0).forEach(x->System.out.println(x));
	}

}
