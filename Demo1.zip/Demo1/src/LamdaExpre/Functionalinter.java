package LamdaExpre;

@FunctionalInterface
interface Arith<T>
{
	T getsum(T a,T b);	
}
public class Functionalinter
{
	public static void main(String[] args)
	{
		//Arith ar0=(int a,int b)->{int c=a-b;return c;};
		Arith<Integer> ar=(a,b)->a+b;
		System.out.println(ar.getsum(5, 6));
		
		Arith<Double> ar1=(a,b)->a*b;
		System.out.println(ar1.getsum(4.4, 7.5));
	}

}
