package LamdaExpre;

import java.util.Arrays;
import java.util.List;

public class ArraySort {
	public static void main(String[] args) {
		int a[]= {5,3,2,5,7,8};
		for(int x:a)
		{
			System.out.println(x);
		}
		Arrays.sort(a);
		for(int x:a)
		{
			System.out.println(x);
		}
		
		int b[]=new int[5];
		Arrays.fill(b,89);
		for(int x:b)
		{
			System.out.println(x);
		}
		
		System.out.println("=============for each with lambda=====================");
		//int arr[]= {2,3,1,5,7,4,8};
		List<Integer> list= Arrays.asList(2,3,4,2,4,1);
		list.forEach(x->System.out.println(x));
		
		System.out.println("=============for each with Method Reference=====================");
		//int arr[]= {2,3,1,5,7,4,8};
		//List<Integer> list= Arrays.asList(2,3,4,2,4,1);
		list.forEach(System.out::println);
		
		System.out.println("=============for each with Method Reference character array=====================");
		List<Character> lchar=Arrays.asList('a','b','c','e');
		lchar.forEach(System.out::println);
	}

}
