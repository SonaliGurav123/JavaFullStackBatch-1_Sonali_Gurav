package LamdaExpre;

import java.util.Arrays;
import java.util.List;
import java.util.Optional;

public class OptionalEx {
	public static void main(String[] args) {
		Optional<String> s=Optional.ofNullable(null);
		
		if(s.isPresent())
		System.out.println(s.get());
		else
			System.out.println("Empty");
		
		List<Integer> list=Arrays.asList(2,4,56,7,5);
		long c=list.stream().count();
		System.out.println(c);
	}

}
