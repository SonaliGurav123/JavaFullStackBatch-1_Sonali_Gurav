package com.verizon;
import java.util.Scanner;
public class Sum {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		// TODO Auto-generated method stub
		System.out.println("Enter Length And breadth:");
		int len=sc.nextInt();
		int breadth=sc.nextInt();
		if(len>0 && breadth>0)
		{	
		int area=len*breadth;
		System.out.println("Area is:"+area);
		}
		else
			System.out.println("Enter the Valid inputs");

	}

}
