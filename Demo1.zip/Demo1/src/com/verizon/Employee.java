package com.verizon;

public class Employee extends Person {
	String de;
	Employee()
	{
		//super(1,"sona");
		System.out.println("In child");
	}
	Employee(String de)
	{
		//super(1,"sona");
		//this();
		this.de=de;
		System.out.println(this.de);
		
	}
	public static void main(String[] args) 
	{
		Employee e=new Employee("rrr");
		Person.show();
	}

}
