package com.verizon;

public class SavingsAccount extends Account
{
	String proof;
	String bname;
	
	void show()
	{
		System.out.println(getbalance());
		deposit(1000);
		System.out.println(getbalance());
		System.out.println(accnumber+"  "+balance);
	}
	
    public static void main(String[] args) 
    {
    	SavingsAccount sa=new SavingsAccount();
    	sa.show();
	
}
}
