package com.verizon;

public class Bankdemo {
	public static void main(String args[])
	{
		Account acc=new Account();
		
		acc.accnumber=101;
		acc.name="Sonali";
		acc.balance=100000;
		
		System.out.println("Name:"+acc.name+"..Account No.:"+acc.accnumber+"..Balance:"+acc.balance);
	
		Account acc1=new Account();
		System.out.println("Name:"+acc1.name+"..Account No.:"+acc1.accnumber+"..Balance:"+acc1.balance);

		Account acc2=new Account(123,2500,"Ram");
		System.out.println("Name:"+acc2.name+"..Account No.:"+acc2.accnumber+"..Balance:"+acc2.balance);

		acc2.withdraw(100.0);
		System.out.println("Name:"+acc2.name+"..Account No.:"+acc2.accnumber+"..Balance:"+acc2.balance);

		System.out.println("Current Balance of "+acc2.name+" is:"+acc2.getbalance());
	}

}
