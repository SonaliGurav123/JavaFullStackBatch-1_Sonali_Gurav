package com.verizon;

public class Account {
	int accnumber;
	double balance;
	String name;
	
	Account()
	{
		accnumber=999;
		balance=1000.00;
		name="payal";
	}
	
	Account(int accnumber,double balance,String name)
	{
		this.accnumber=accnumber;
		this.balance=balance;
		this.name=name;
	}
	
	void deposit(double amt)
	{
		balance+=amt;
	}
	
	void withdraw(double amt)
	{
		balance-=amt;
	}
	
	double getbalance()
	{
		return balance;
	}
	

}
