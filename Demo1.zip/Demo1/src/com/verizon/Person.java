package com.verizon;

public class Person {
	int id;
	String name;
	Person()
	{
		System.out.println("In parent");
	}
	Person(int id,String name)
	{
		this.id=id;
		this.name=name;
		System.out.println("In paremetrized constructor:"+id+"  "+name);

	}
	public static void show()
	{
		System.out.println("Hello");
	}

}
