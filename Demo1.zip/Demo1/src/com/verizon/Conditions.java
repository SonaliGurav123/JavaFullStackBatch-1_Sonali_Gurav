package com.verizon;

import java.util.Scanner;

public class Conditions {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
		/*int i=1;
		while(i<=10)
		{
			i++;

			if(i==5)
			{	continue;
			}
			else
			{
			System.out.println(i);
			}

		}
		for(int i=0;i<=10;i++)
		{
			if(i==5)
			  continue;
			System.out.println(i);
			
		}

		int a[]= {2,3,5,6,7};
		System.out.println("Array is:");
		for(int x=0;x<a.length;x++)
		{
			System.out.println(a[x]);
		}
		int sum=0;
		for(int x=0;x<a.length;x++)
		{
			sum+=a[x];
		}
		System.out.println("Sum is:"+sum);
		int b[]=new int[5];
		System.arraycopy(a, 1, b, 1,3);
		for(int x=0;x<b.length;x++)
		{
			System.out.println(b[x]);
		}
	}*/

		System.out.println("Enter the operator:");
		char ch=sc.next().charAt(0);
		System.out.println("Enter 2 Numbers:");
		int a=sc.nextInt();
		int b=sc.nextInt();
		
		switch(ch)
		{
		case '+':System.out.println("Sum is:"+(a+b));break;
		case '-':System.out.println("diff is:"+(a-b));break;
		default:System.out.println("Wrong Operator");
		}
		}
		
}
