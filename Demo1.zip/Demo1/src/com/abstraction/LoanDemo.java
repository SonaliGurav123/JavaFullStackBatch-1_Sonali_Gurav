package com.abstraction;

public class LoanDemo 
{
	public static void main(String[] args) 
	{
		
		Loan l=new HousingLoan();
		l.applyloan("SSS", 100000.00);
		l.docs();
		System.out.println(l.getEmi());
		
		Loan v=new VehicleLoan();
		v.applyloan("Raj", 1000000.00);
		v.docs();
		System.out.println(v.getEmi());
	}

}
