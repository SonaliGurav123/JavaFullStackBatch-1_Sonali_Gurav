package com.abstraction;

public class HousingLoan extends Loan{
	
	void applyloan(String name,double amt)
	{
		System.out.println(name+" applied succussfully for Housing Loan of "+amt);
	}

	void docs()
	{
		System.out.println("All Required Docs Are submitted!");
	}
	int getEmi()
	{
		return 999;
	}
}
