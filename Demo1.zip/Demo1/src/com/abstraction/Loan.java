package com.abstraction;

abstract public class Loan {

	abstract void applyloan(String name,double amt);
	abstract void docs();
	abstract int getEmi();
	
}
