package com.interfaces;

public interface Parking {
	void getslot();

}
