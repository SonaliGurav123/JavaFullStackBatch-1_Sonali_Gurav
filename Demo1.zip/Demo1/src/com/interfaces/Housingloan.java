package com.interfaces;

public class Housingloan implements Loan,surity{
	
	public void applyloan(String name,double amt)
	{
		System.out.println(name+" Applied Housing Loan of "+amt);
	}
	
	public void docs()
	{
		System.out.println("Submitted!!");
	}
	
	public int getEmi()
	{
		return 999;
	}
	
	public void sdocs()
	{
		System.out.println("Surity Docs Submitted!!");
	}
	
	

}
