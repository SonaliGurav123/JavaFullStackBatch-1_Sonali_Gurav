package com.interfaces;

interface Loan {
	
	void applyloan(String name,double amt);
	void docs();
	int getEmi();

}
