package com.interfaces;

public class LoanDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Loan l=new Housingloan();
		surity sh=new Housingloan();
		l.applyloan("Laksh", 10000.00);
		l.docs();
		System.out.println(l.getEmi());
		
		sh.sdocs();
		
		Loan vl=new Vehicleloan();
		surity sv=new Vehicleloan();
		Parking pv=new Vehicleloan();
		vl.applyloan("jash", 100000.00);
		vl.docs();
		System.out.println(vl.getEmi());
		
		sv.sdocs();
		pv.getslot();
		
	}

}
