package com.interfaces;

public class Vehicleloan implements Loan,surity,Parking{
	public void applyloan(String name,double amt)
	{
		System.out.println(name+" Applied Vehicle Loan of "+amt);
	}
	
	public void docs()
	{
		System.out.println("Submitted!!");
	}
	
	public int getEmi()
	{
		return 999;
	}
	
	public void sdocs()
	{
		System.out.println("Surity Docs Submitted!!");
	}

	public void getslot()
	{
		System.out.println("Slot is booked!!");

	}
}
