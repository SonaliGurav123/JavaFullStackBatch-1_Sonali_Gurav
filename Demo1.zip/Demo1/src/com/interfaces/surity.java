package com.interfaces;

public interface surity {
	void sdocs();

}
