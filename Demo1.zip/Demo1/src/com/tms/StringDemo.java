package com.tms;

import java.util.StringTokenizer;

public class StringDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		String name="S";
		String name1="Z";
		System.out.println(name.compareTo(name1));
		String s=new String("Yes");
		String s1=new String("Yes");
		System.out.println(name.equals(name1));
		System.out.println(s.length());

		StringBuffer sb=new StringBuffer("Java");
		System.out.println(sb);
		sb.append(999);
		System.out.println(sb);

		sb.insert(3,"xxx");
		System.out.println(sb);
		
		sb.delete(2,3);
		System.out.println(sb);

		 String[] result = "this is a test".split(" ");
	     for (int x=0; x<result.length; x++)
	         System.out.println(result[x]);

		StringBuilder a=new StringBuilder("Java");
		a.ensureCapacity(80);
		System.out.println(a.capacity());
		
		String line="This is the tokenizer example";
		StringTokenizer st=new StringTokenizer(line);
		while(st.hasMoreTokens())
		{
			System.out.println(st.nextToken());
		}
	}

}
