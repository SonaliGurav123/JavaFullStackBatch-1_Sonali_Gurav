package com.poly;

public class Mride extends Dynamicpoly {
	
	@Override
	void sq(int s)
	{
		System.out.println("Perimeter is:"+(4*s));
	}
	public static void main(String[] args) {
		Dynamicpoly d=new Mride();
		d.sq(4);
		Dynamicpoly d1=new Dynamicpoly();
        d1.sq(5);
		
	}

}
