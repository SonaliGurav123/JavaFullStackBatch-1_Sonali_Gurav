package com.poly;

public class Mride1 extends Mride
{
	@Override
	void sq(int a)
	{
		
	}

}
