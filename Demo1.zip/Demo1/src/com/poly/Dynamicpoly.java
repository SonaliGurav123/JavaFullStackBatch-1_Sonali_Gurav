package com.poly;

public class Dynamicpoly {
	void sq(int s)
	{
		System.out.println("Area of Square:"+(s*s));
	}

}
