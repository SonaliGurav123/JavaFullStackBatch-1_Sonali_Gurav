package com.poly;

public class Staticpoly {
	
	void area(int s)
	{
		System.out.println("Area of Square:"+(s*s));
	}
	void area(int l,int b)
	{
		System.out.println("Area of Rectangle:"+(l*b));
	}
	void area(double r)
	{
		System.out.println("Area of Circle:"+(3.14*r*r));
	}
	
	public static void main(String[] args) {
		Staticpoly s=new Staticpoly();
		s.area(3);
		s.area(5,8);
		s.area(4.00);
	}

}
