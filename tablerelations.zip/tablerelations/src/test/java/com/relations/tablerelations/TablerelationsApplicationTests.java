package com.relations.tablerelations;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TablerelationsApplicationTests {

	@Test
	void contextLoads() {
	}

}
