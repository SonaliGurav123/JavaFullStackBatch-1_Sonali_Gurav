package com.relations.tablerelations.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.relations.tablerelations.dao.StudentDao;
import com.relations.tablerelations.model.Student;

@Service
public class StudentService {
	
	@Autowired
	StudentDao studentDao;
	
	public String addStudent(Student student)
	{
		studentDao.save(student);
		return "Added";
	}

}
