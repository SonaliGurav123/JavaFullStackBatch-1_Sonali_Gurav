package com.relations.tablerelations.model;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;

@Entity
public class Address {
	
	@Id
	private int addressId;
	private String address1;
	private String state;
	private int zipcode;
	
	public Address() {
		super();
	}

	public Address(int addressId, String address1, String state, int zipcode) {
		super();
		this.addressId = addressId;
		this.address1 = address1;
		this.state = state;
		this.zipcode = zipcode;
	}

	public int getAddressId() {
		return addressId;
	}

	public void setAddressId(int addressId) {
		this.addressId = addressId;
	}

	public String getAddress1() {
		return address1;
	}

	public void setAddress1(String address1) {
		this.address1 = address1;
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

	public int getZipcode() {
		return zipcode;
	}

	public void setZipcode(int zipcode) {
		this.zipcode = zipcode;
	}

	@Override
	public String toString() {
		return "Address [addressId=" + addressId + ", address1=" + address1 + ", state=" + state + ", zipcode="
				+ zipcode + "]";
	}
	
	
	
	

}
