package com.relations.tablerelations.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.relations.tablerelations.model.Student;

@Repository
public interface StudentDao extends JpaRepository<Student,Integer>{

}
