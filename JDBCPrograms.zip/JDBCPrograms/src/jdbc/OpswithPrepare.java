package jdbc;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;

public class OpswithPrepare {
	
	public static void main(String[] args) throws ClassNotFoundException, SQLException {
		
		Class.forName("oracle.jdbc.driver.OracleDriver");
		
		Connection conn=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","system","SonaliDatabase");
		
		System.out.println("Done");
		
		Scanner sc=new Scanner(System.in);
		Statement st=conn.createStatement();

		
		
		/*PreparedStatement psi=conn.prepareStatement("insert into course values(?,?,?)");
		System.out.println("Enter the Cid , Cname and duration:");
		psi.setInt(1, sc.nextInt());
		psi.setString(2, sc.next());
		psi.setInt(3, sc.nextInt());
		psi.executeUpdate();*/
		
		/*PreparedStatement psi=conn.prepareStatement("update course set duration=? where cid=?");
		System.out.println("Enter the Cid to be updated:");
		psi.setInt(2, sc.nextInt());
		System.out.println("Enter the new duration:");
		psi.setInt(1, sc.nextInt());
		psi.executeUpdate();
		System.out.println("Updated");*/
		
		PreparedStatement psi=conn.prepareStatement("delete from course where cid=?");
		System.out.println("Enter the Cid to be deleted");
		psi.setInt(1, sc.nextInt());
		psi.executeUpdate();
		System.out.println("Deleted");

	}

}
