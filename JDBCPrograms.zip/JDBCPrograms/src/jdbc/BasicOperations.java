package jdbc;
	import java.sql.Connection;
	import java.sql.DriverManager;
	import java.sql.PreparedStatement;
	import java.sql.ResultSet;
	import java.sql.ResultSetMetaData;
	import java.sql.SQLException;
	import java.sql.Statement;
	import java.util.Scanner;

	public class BasicOperations {
		
		public static void main(String[] args) throws ClassNotFoundException, SQLException {
			
			Class.forName("oracle.jdbc.driver.OracleDriver");
			
			Connection conn=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","system","SonaliDatabase");
			
			System.out.println("Done");
			
			Scanner sc=new Scanner(System.in);
			Statement st=conn.createStatement();

			//Insert value
			//st.executeUpdate("insert into course values(201,'Java',4)");
			//System.out.println("Insertion Done");
			
			//Delete value
			/*System.out.println("Enter the Course Id to be deleted:");
			int id=sc.nextInt();
			st.executeUpdate("delete from course where cid="+id);
			System.out.println("Deletion Done");*/
			
			System.out.println("Enter the Course Id to be updated:");
			int did=sc.nextInt();
			System.out.println("Enter the Duration to be updated:");
			int dur=sc.nextInt();
			st.executeUpdate("update course set duration="+dur+"where cid="+did);
			System.out.println("Updation Done");

			
			
			
			

		}
	}


