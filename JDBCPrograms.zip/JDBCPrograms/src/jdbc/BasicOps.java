package jdbc;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;

public class BasicOps {
	
	public static void main(String[] args) throws ClassNotFoundException, SQLException {
		
		Class.forName("oracle.jdbc.driver.OracleDriver");
		
		Connection conn=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","system","SonaliDatabase");
		
		System.out.println("Done");
		
		Scanner sc=new Scanner(System.in);
		Statement st=conn.createStatement();
		PreparedStatement ps=conn.prepareStatement("insert into course values(?,?,?)");
		System.out.println("enter 3 values in course table:");
		/*for(int i=0;i<3;i++)
		{
			ps.setInt(1, sc.nextInt());
			ps.setString(2, sc.next());
			ps.setInt(3, sc.nextInt());
			ps.execute();	
		}*/
		
		ResultSet rs=st.executeQuery("select * from course");
		ResultSetMetaData rsmd=rs.getMetaData();
		System.out.println("No. of columns:"+rsmd.getColumnCount());
		
		for(int i=1;i<=rsmd.getColumnCount();i++)
		{
			System.out.println(rsmd.getColumnName(i));
		}
		System.out.println("=======================");
		
		while(rs.next())
		{
			System.out.println(rs.getString(1)+"  "+rs.getString(2)+" "+rs.getString(3));
		}
		
	}
		
	}


