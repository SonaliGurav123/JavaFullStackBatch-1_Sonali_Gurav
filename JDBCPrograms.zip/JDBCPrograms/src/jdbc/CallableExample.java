package jdbc;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Types;
import java.util.Scanner;
import java.util.concurrent.Callable;

public class CallableExample {
	
	public static void main(String[] args) throws ClassNotFoundException, SQLException {
		
		Class.forName("oracle.jdbc.driver.OracleDriver");
		Connection conn=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","system","SonaliDatabase");
		
		Scanner sc=new Scanner(System.in);
		CallableStatement cal=conn.prepareCall("{ CALL square(?,?)}");
		System.out.println("Enter the number:");
		cal.setInt(1,sc.nextInt());
		
		cal.registerOutParameter(2, Types.INTEGER);
		cal.execute();
		
		System.out.println("Square is:"+cal.getInt(2));
		
	}

}
