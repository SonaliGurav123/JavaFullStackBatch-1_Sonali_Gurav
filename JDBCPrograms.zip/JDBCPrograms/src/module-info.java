/**
 * 
 */
/**
 * 
 */
module JDBCPrograms {
	requires java.sql;
}