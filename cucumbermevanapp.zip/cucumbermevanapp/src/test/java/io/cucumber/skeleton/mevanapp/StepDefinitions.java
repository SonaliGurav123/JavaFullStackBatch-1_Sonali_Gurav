package io.cucumber.skeleton.mevanapp;

import io.cucumber.java.en.*;


import static org.junit.jupiter.api.Assertions.*;

public class StepDefinitions {

    @Given("I have {int} cakes in my belly")
    public void anBellyScenario(int cakes) {
    	Belly belly=new Belly();
    	belly.eat(cakes);
    }

    @When("I wait 1 hour")
    public void allStepDefinitionsAreImplemented() {
    	Belly belly=new Belly();
    	belly.waitStep();
    }

    @Then("my belly should grow")
    public void theScenarioPasses() {
    	Belly belly=new Belly();
    	belly.endProcess();
    }

}
