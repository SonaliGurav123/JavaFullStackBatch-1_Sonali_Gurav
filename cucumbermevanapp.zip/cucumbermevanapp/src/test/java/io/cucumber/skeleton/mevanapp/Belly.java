package io.cucumber.skeleton.mevanapp;

public class Belly {
	
	public void eat(int cakes)
	{
		System.out.println("Step Started");
	}
	public void waitStep()
	{
		System.out.println("Waiting after Step1");
	}
	public void endProcess()
	{
		System.out.println("all steps completed");
	}

}
