package sets;

import java.util.Set;
import java.util.TreeSet;

public class Sets {
	public static void main(String[] args) {
		Set<String> s=new TreeSet<>();
		
		s.add("Sonali");
		s.add("Sheru");
		s.add("rahul");
		s.add("Aady");
		s.add("Prem");
		
		System.out.println(s);
		System.out.println(s.size());
		System.out.println(s.remove("rahul"));
		System.out.println(s.size());



		
	}

}
