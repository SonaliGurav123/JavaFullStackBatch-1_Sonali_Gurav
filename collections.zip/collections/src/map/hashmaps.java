package map;

import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;

public class hashmaps {
	public static void main(String[] args) {
		Map<Integer,String> hm=new HashMap<>();
		hm.put(1,"sss");
		hm.put(2, "aaa");
		hm.put(3, "ddd");
		hm.put(4, "fffs");
		hm.put(6, "ffffg");
		hm.put(8, "fffd");
		hm.put(5, "fff3");

		System.out.println(hm);
		
		Set s=hm.keySet();
		System.out.println(s);
		
		Collection val=hm.values();
		System.out.println(val);
		
		Set kv=hm.entrySet();
		Iterator i=kv.iterator();
		while(i.hasNext())
		{
			Map.Entry entry=(Map.Entry)i.next();
			System.out.println(entry.getKey()+"  "+entry.getValue());
		}
	}

}
