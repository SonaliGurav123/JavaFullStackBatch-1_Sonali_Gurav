package custom;

import java.util.List;

interface CourseService
	{
		String addCourse(Course c);
		String deleteCourse(Integer id);
		String updateCourse(Integer couid);
		List<Course> listCourse();

	}


