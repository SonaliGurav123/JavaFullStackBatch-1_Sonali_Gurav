package custom;

public class Course {
		Integer id;
		String Cname;
		Double fee;
		public Course(Integer id, String cname, Double fee) {
			super();
			this.id = id;
			Cname = cname;
			this.fee = fee;
		}
		@Override
		public String toString() {
			return "Course [id=" + id + ", Cname=" + Cname + ", fee=" + fee + "]";
		}
		
		
	
}
