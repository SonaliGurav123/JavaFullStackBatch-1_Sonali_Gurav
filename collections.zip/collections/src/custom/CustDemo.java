package custom;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import custom.Course;


public class CustDemo {
	public static void main(String[] args) 
	{
		CourseService c=new CourseServiceimp();

		int ch;
		do
		{
			System.out.println("\nMenu:");
			System.out.println("1:Add:");
			System.out.println("2:Delete:");
			System.out.println("3:Update:");
			System.out.println("4:Display:");
			System.out.println("5:Exit:");
			
			Scanner sc=new Scanner(System.in);
			System.out.println("Enter Choice:\n");
			ch=sc.nextInt();
			
			switch(ch)
			{
			case 1:System.out.println("Enter Course Id:\n");
				int id1=sc.nextInt();
				System.out.println("Enter Course Name:\n");
				String name1=sc.next();
				System.out.println("Enter Course fees:\n");
				Double fee1=sc.nextDouble();
				Course c1=new Course(id1,name1,fee1);
				c.addCourse(c1);
				break;
				
			case 2:System.out.println("Enter Course Id to be deleted:\n");
			int id2=sc.nextInt();
			c.deleteCourse(id2);
			break;
			
			case 3:System.out.println("Enter Course Id to be updated:\n");
			int id3=sc.nextInt();
			c.updateCourse(id3);
			break;
			
			case 4:	
				List<Course> rl=c.listCourse();
			    for(Course c4:rl)System.out.println(c4);
			    break;
			case 5:break;
			
			}
		
			
		}while(ch!=5);
		
		/*Course c1=new Course(40,"java",400.00);
		Course c2=new Course(41,"java",400.00);

		CourseService c=new CourseServiceimp();
		c.addCourse(c1);
		c.addCourse(c2);

		
		c.deleteCourse(1);

		List<Course> rl=c.listCourse();
		for(Course c4:rl)System.out.println(c4);*/
		
	}
	

}
