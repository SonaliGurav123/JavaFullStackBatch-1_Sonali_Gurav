package custom;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;


	class CourseServiceimp implements CourseService
	{
		List<Course> courselist=new ArrayList<>();

		public String addCourse(Course c)
		{
			courselist.add(c);
			return "ok";
		}
		
		
		public String deleteCourse(Integer id)
	    {
			
			Iterator itr=courselist.iterator();
			while(itr.hasNext())
			{
				Course cou=(Course)itr.next();
				if(cou.id==id)
					itr.remove();
			}
			return "Deleted Successfully";

	    }
		public String updateCourse(Integer couid)
		{
			Iterator itr1=courselist.iterator();
			while(itr1.hasNext())
			{
				Course cou=(Course)itr1.next();
				if(cou.id==couid)
					cou.fee=cou.fee+1000;
			}
			return "Updated Successfully";


		}
		public List<Course> listCourse()
		{
			return courselist;

		}

	}

