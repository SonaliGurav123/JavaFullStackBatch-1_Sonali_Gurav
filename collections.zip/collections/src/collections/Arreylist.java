package collections;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class Arreylist {
	
	public static void main(String[] args) {
		List l=new ArrayList();
		
		l.add(3);
		l.add("sss");
		System.out.println(l);
		System.out.println(l.size());
		System.out.println(l.indexOf("sss"));
		
		l.forEach(x->System.out.println(x));
		
		Iterator i=l.iterator();
		while(i.hasNext())
		{
			System.out.println(i.next());
		}

	}

}
