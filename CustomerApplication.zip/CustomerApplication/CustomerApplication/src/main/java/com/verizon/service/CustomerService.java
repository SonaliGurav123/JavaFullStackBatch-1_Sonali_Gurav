package com.verizon.service;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.verizon.dao.CustomerDao;
import com.verizon.model.Customer;

import jakarta.transaction.Transactional;
@Service//@Component
@Transactional
public class CustomerService {
	@Autowired
	CustomerDao customerDao;
	public String addCustomer(Customer cust) {
		customerDao.save(cust);
		return "Added";
	}
	public   List<Customer> getAllCustomers() {
		List<Customer>  custList=customerDao.findAll();
		return custList;
	}
	public Customer updateCustomer(Integer cid,Customer cust) {
		Customer cust1=customerDao.findById(cid).get();
		cust1.setEmail(cust.getEmail());
		return customerDao.findById(cid).get();
	}
	public Customer deleteCustomer(Integer cid) {
		Customer cust1=customerDao.findById(cid).get();
		if(cust1!=null)
		customerDao.deleteById(cid);
		return cust1;
		}
	}
