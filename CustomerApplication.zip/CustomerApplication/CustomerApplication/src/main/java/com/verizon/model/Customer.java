package com.verizon.model;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name="Customer1")
public class Customer {
	@Id
	Integer cid;
	@Column
	String cname;
	String Email;
	Customer(){
	
	}
	public Customer(Integer cid, String cname, String email) {
		super();
		this.cid = cid;
		this.cname = cname;
		Email = email;
	}
	public Integer getCid() {
		return cid;
	}
	public void setCid(Integer cid) {
		this.cid = cid;
	}
	public String getCname() {
		return cname;
	}
	public void setCname(String cname) {
		this.cname = cname;
	}
	public String getEmail() {
		return Email;
	}
	public void setEmail(String email) {
		Email = email;
	}
	@Override
	public String toString() {
		return "Customer [cid=" + cid + ", cname=" + cname + ", Email=" + Email + "]";
	}
	
	

}
