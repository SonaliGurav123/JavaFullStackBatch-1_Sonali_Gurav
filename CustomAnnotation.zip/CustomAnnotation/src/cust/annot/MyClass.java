package cust.annot;

public class MyClass {
	
	@MyCustomAnnot(value="sss",count=10)
	public void mymethod()
	{
		
	}

}
