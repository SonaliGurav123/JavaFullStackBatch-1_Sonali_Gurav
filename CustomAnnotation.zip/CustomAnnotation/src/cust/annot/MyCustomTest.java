package cust.annot;

import java.lang.annotation.Annotation;
import java.lang.reflect.Method;

public class MyCustomTest {
	
	 public static void main(String[] args) throws NoSuchMethodException {
	        Class<MyClass> x = MyClass.class;
	        Method method = x.getMethod("mymethod");

	        if (method.isAnnotationPresent((Class<? extends Annotation>) MyCustomAnnot.class)) {
	            MyCustomAnnot annotation = method.getAnnotation(MyCustomAnnot.class);

	            String value = annotation.value();
	            int count = annotation.count();

	            System.out.println("Annotation value: " + value);
	            System.out.println("Annotation count: " + count);
	        }
	    }

}
