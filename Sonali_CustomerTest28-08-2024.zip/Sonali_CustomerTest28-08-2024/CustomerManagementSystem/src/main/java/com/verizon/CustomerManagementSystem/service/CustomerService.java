package com.verizon.CustomerManagementSystem.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.verizon.CustomerManagementSystem.dao.CustomerDao;
import com.verizon.CustomerManagementSystem.model.Customer;

@Service
public class CustomerService {
	
	@Autowired
	CustomerDao customerDao;
	
	public String addCustomer(Customer cust)
	{
		customerDao.save(cust);
		return "New Customer is Added";
	}
	
	public List<Customer> getAllCustomers()
	{
		List<Customer> c=customerDao.findAll();
		return c;
	}
	
	
	public Customer updateCustomer(Integer cid,Customer cust) {
		Customer cust1=customerDao.findById(cid).get();
		cust1.setEmail(cust.getEmail());
		return customerDao.findById(cid).get();
	}
	/*public Customer updateCostomer(Integer cid,Customer cust1)
	{
		Customer c2=customerDao.findById(cid).get();
		c2.setEmail(cust1.getEmail());
		return c2;
	}*/
	
	public Customer deleteCostomer(Integer cid)
	{
		Customer c2=customerDao.findById(cid).get();
		if(c2!=null)
			customerDao.deleteById(cid);
		return c2;
	}
	
	
}
