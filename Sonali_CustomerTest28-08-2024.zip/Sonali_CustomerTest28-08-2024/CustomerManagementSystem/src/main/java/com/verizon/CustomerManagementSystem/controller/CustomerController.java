package com.verizon.CustomerManagementSystem.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.verizon.CustomerManagementSystem.model.Customer;
import com.verizon.CustomerManagementSystem.service.CustomerService;

@RestController
public class CustomerController {
	
	@Autowired
	CustomerService customerService;
	
	@PostMapping("/customer")
	public String addCust(@RequestBody Customer cust)
	{
		return customerService.addCustomer(cust);
	}
	
	@GetMapping("/customer")
	public List<Customer> getAllCust()
	{
		List<Customer> c1=customerService.getAllCustomers();
		return c1;
	}
	
/*	@PutMapping("/customer/{cid}")
	public Customer updateCust(@PathVariable("cid") Integer cid,@RequestBody Customer cust)
	{
		return customerService.updateCostomer(cid, cust);
	}*/
	
	
	@PutMapping("/customer/{cid}") 
	public Customer updatePlanDetails(@PathVariable("cid") Integer cid,@RequestBody Customer cust) {
		
		return  customerService.updateCustomer(cid, cust); 
	}
	
	@DeleteMapping("/customer/{cid}")
	public Customer deleteCust(@PathVariable("cid") Integer cid)
	{
		return customerService.deleteCostomer(cid);
	}
	
}
