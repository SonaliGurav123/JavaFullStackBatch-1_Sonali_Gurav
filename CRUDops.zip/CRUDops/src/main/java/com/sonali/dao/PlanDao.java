package com.sonali.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.sonali.model.Plan;

@Repository
//@Component
public interface PlanDao  extends JpaRepository<Plan,Integer>{

}

