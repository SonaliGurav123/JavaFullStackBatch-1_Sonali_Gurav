package com.testing;

public class Loan {
	
	int getEmi(int amt)
	{
		return (amt/2);
	}

}
