package com.testing;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class LoanTest {

	@Test
	void testGetEmi() {
		Loan l=new Loan();
		assertEquals(1200,l.getEmi(2400));
		//fail("Not yet implemented");
	}

}
