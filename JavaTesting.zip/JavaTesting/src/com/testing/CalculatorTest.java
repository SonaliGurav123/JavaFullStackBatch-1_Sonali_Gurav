package com.testing;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

class CalculatorTest {

	Calculator c;
	@BeforeAll
	static void setUpBeforeClass() throws Exception {
		System.out.println("Testing started");
	}

	@AfterAll
	static void tearDownAfterClass() throws Exception {
		System.out.println("Testing Ended");

	}

	@BeforeEach
	void setUp() throws Exception {
		c=new Calculator();
	}

	@AfterEach
	void tearDown() throws Exception {
		System.out.println("Teared down");
	}

	@Test
	void testSum() {
		assertEquals(11,c.sum(5, 6));
		//fail("Not yet implemented");
	}

	@Test
	void testDiff() {
		assertEquals(1,c.diff(7, 6));

		//fail("Not yet implemented");
	}

	@Test
	void testProd() {
		assertEquals(30,c.prod(5, 6));

		//fail("Not yet implemented");
	}

}
