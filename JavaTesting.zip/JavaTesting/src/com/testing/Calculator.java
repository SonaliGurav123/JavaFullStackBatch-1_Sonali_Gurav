package com.testing;

public class Calculator {
	
	int sum(int a,int b)
	{
		return (a+b);
	}

	int diff(int a,int b)
	{
		return (a-b);
	}

	int prod(int a,int b)
	{
		return (a*b);
	}

}
