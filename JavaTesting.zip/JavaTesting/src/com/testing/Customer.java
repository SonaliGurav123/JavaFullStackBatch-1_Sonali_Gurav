package com.testing;

public class Customer {
	
	public int getBalance()
	{
		return 1000;
	}

}
