package com.verizon.service;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.verizon.dao.ProductDao;
import com.verizon.exception.ProductNotFoundException;
import com.verizon.model.Product;
import jakarta.transaction.Transactional;
@Service
@Transactional
public class ProductService {
	@Autowired
	ProductDao productDao;
	public String addProduct(Product product)
	{
	
		productDao.save(product);
		return "Added";
	}
	
	public   List<Product> getProducts()
	{
		List<Product> productList=new ArrayList<>();
		productList=productDao.findAll();
		return productList;
	}
	
	public   Product getProduct(Integer id)
	{
		Optional<Product> product=productDao.findById(id);
		return product.orElseThrow(()->new ProductNotFoundException("Product Not Found for Product Id:"+id)) ;
	}
	
	public   List<Product> getProductsBetweenLowHigh11(Integer low,Integer high)
	{
		List<Product> productList= new ArrayList<>();
		productList=productDao.getProductsBetweenLowHigh(low,high);
		return productList;
	}
	
	public Product updateProduct(Integer pid,Product product)
	{
		Product product1=new Product();  
		product1=productDao.findById(pid).orElseThrow(()->new ProductNotFoundException("Product Not Found for Product Id:"+pid));
		product1.setPrice(product.getPrice());
		return product1;
	}
	
	public Product deleteProduct(Integer pid) 
	{
		Product product1=new Product();  
		product1=productDao.findById(pid).orElseThrow(()->new ProductNotFoundException("Product Not Found for this Id"));
        productDao.deleteById(pid);
		return product1;
	}
}
